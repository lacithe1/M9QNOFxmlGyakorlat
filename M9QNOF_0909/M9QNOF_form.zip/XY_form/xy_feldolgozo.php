<html>
<body>

Hello <?php echo $_POST["name"]; ?>!<br>
A beírt adataid:<br> 
PIN Kód: <?php echo $_POST["pin"]; ?> <br>
Kedvenc gyümölcs: <?php echo $_POST["fruit"]; ?> <br>
Életkor: <?php echo $_POST["age"]; ?> <br>
Magasság: <?php echo $_POST["height"]; ?><br>
Magasság: <?php echo $_POST["size"]; ?><br>
Önbizalom: <?php echo $_POST["ONBIZALOM"]; ?><br>


</body>
</html>